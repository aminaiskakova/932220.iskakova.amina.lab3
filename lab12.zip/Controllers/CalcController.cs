using Microsoft.AspNetCore.Mvc;
using task12.Models;
using System.ComponentModel.DataAnnotations;
using System.Reflection;

namespace task12.Controllers
{
    // CalculatorController.cs
    public class CalcController : Controller
    {

        /* MODEL PARSING IN SINGLE ACTION */
        [HttpGet]
        public IActionResult ManualParsingInSingleAction()
        {
            return View();
        }

        [HttpPost]
        public IActionResult ManualParsingInSingleAction(IFormCollection form)
        {

            var num1Str = form["num1"];
            var num2Str = form["num2"];
            var operationStr = form["operation"];

            if (double.TryParse(num1Str, out double num1) && 
                double.TryParse(num2Str, out double num2) && 
                Enum.TryParse(operationStr, out Operations operation))
            {
                double result = operation switch
                {
                    Operations.Add => num1 + num2,
                    Operations.Subtract => num1 - num2,
                    Operations.Multiply => num1 * num2,
                    Operations.Divide => num2 != 0 ? num1 / num2 : double.NaN,
                    _ => 0
                };

                ViewBag.Num1 = num1;
                ViewBag.Num2 = num2;
                ViewBag.Operation = GetOperationSymbol(operation);
                ViewBag.Result = double.IsNaN(result) ? "На 0 делить нельзя, а умножать можно!" : result.ToString();

                return View("Result");
            }
            else
            {
                ViewBag.Error = "!!ОШИБКА: некорректный ввод :)";
                return View();
            }
        }


        // для изъятия из enum соответствубщего знака
        private string GetOperationSymbol(Operations operation)
        {
            var displayAttribute = operation.GetType()
                                            .GetMember(operation.ToString())[0]
                                            .GetCustomAttribute<DisplayAttribute>();
            return displayAttribute?.Name ?? operation.ToString();
        }


        
        [HttpGet]
        public IActionResult ManualParsingInSeparateActions()
        {
            return View();
        }

        [HttpPost]
        public IActionResult ManualParsingInSeparateActions(IFormCollection form)
        {

            var num1 = form["num1"];
            var num2 = form["num2"];
            var operation = form["operation"];

            // Action - Validation
            if (!Validate(num1, num2, operation, out double firstNumber, out double secondNumber, out Operations selectedOperation))
            {
                return View();
            }

            // Action - Calculate 
            double result = Calculate(firstNumber, secondNumber, selectedOperation);

            ViewBag.Num1 = firstNumber;
            ViewBag.Num2 = secondNumber;
            ViewBag.Operation = GetOperationSymbol(selectedOperation);
            ViewBag.Result = double.IsNaN(result) ? "На 0 ни в коем случае делить нельзя!" : result.ToString();

            return View("Result");
        }

        // Action - Validation
        private bool Validate(string num1, string num2, string operation, out double firstNumber, out double secondNumber, out Operations selectedOperation)
        {
            bool isValid = true;
            firstNumber = secondNumber = 0;
            selectedOperation = Operations.Add; // default

            if (!double.TryParse(num1, out firstNumber) || !double.TryParse(num2, out secondNumber))
            {
                ViewBag.Error = "ошибка: некорректный ввод";
                isValid = false;
            }

            if (!Enum.TryParse(operation, out selectedOperation))
            {
                ViewBag.Error = "error";
                isValid = false;
            }

            return isValid;
        }

        // Action - Calculate
        private double Calculate(double num1, double num2, Operations operation)
        {
            return operation switch
            {
                Operations.Add => num1 + num2,
                Operations.Subtract => num1 - num2,
                Operations.Multiply => num1 * num2,
                Operations.Divide => num2 != 0 ? num1 / num2 : double.NaN,
                _ => 0
            };
        }
       



        [HttpGet]
        public IActionResult ModelBindingParameters()
        {
            return View();
        }

        [HttpPost]
        public IActionResult ModelBindingParameters(string num1, string num2, Operations operation)
        {

            if (!double.TryParse(num1, out double number1) || !double.TryParse(num2, out double number2))
            {
                ViewBag.Error = "ОШИБКААА: некорректный ввод!!";
                return View();
            }

            double result = operation switch
            {
                Operations.Add => number1 + number2,
                Operations.Subtract => number1 - number2,
                Operations.Multiply => number1 * number2,
                Operations.Divide => number2 != 0 ? number1 / number2 : double.NaN,
                _ => 0
            };

            ViewBag.Num1 = num1;
            ViewBag.Num2 = num2;
            ViewBag.Operation = GetOperationSymbol(operation);
            ViewBag.Result = double.IsNaN(result) ? "На ноль делить нельзя!" : result.ToString();

            return View("Result");
        }
      




        [HttpGet]
        public IActionResult ModelBindingInSeparateModel()
        {
            return View();
        }

        [HttpPost]
        public IActionResult ModelBindingInSeparateModel(CalcModel model)
        {
            if (ModelState.IsValid)
            {
                double result = model.Operation switch
                {
                    Operations.Add => model.Num1 + model.Num2,
                    Operations.Subtract => model.Num1 - model.Num2,
                    Operations.Multiply => model.Num1 * model.Num2,
                    Operations.Divide => model.Num2 != 0 ? model.Num1 / model.Num2 : double.NaN,
                    _ => 0
                };

                ViewBag.Num1 = model.Num1;
                ViewBag.Num2 = model.Num2;
                ViewBag.Operation = GetOperationSymbol(model.Operation);
                ViewBag.Result = double.IsNaN(result) ? "На ноль делить нельзя!" : result.ToString();
                return View("Result");
            }
            else
            {
                ViewBag.Error = "некорректный ввод :(";
                return View();
            }
        }
       
    }

}