using System.ComponentModel.DataAnnotations;

namespace task12.Models
{
    public enum Operations
    {
        [Display(Name = "+")]
        Add,
        [Display(Name = "-")]
        Subtract,
        [Display(Name = "*")]
        Multiply,
        [Display(Name = "/")]
        Divide
    }
}
