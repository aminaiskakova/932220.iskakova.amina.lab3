using System.ComponentModel.DataAnnotations;

namespace task12.Models
{
    public class CalcModel
    {
        [Required(ErrorMessage = "error")]
        public double Num1 { get; set; }

        [Required(ErrorMessage = "error")]
        public double Num2 { get; set; }

        [Required(ErrorMessage = "error")]
        public Operations Operation { get; set; }
    }
}