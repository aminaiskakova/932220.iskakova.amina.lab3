namespace task13.Models
{
    public record QuizModel(Quiz quiz);
}